
REG-ENGINE LIFEBOAT ARCHIVE
===========================
This archive contains the full compliance state of your clinic.
It is designed to be readable by any standard computer without specialized software.

CONTENTS:
- clinic_metadata.json: Basic information about this export.
- compliance_status.json: The last known status of your safety controls.
- evidence/: Folder containing immutable logs of your compliance activities.
